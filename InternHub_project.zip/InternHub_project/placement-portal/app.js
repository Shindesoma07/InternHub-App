const K='Internhub_v1',SK='Internhub_session',ST=['Applied','Shortlisted','Interview','Selected','Rejected'];
const BR=['CSE','IT','ECE','EEE','Mechanical','Civil','Other'];
let mem=null,DB,me=null,view='';
function h(s){let a=5381;for(const c of s)a=((a*33)^c.charCodeAt(0))>>>0;return a.toString(36)+s.length}
function uid(){return Math.random().toString(36).slice(2,10)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function load(){try{const r=localStorage.getItem(K);if(r)return JSON.parse(r)}catch(e){}return mem||seed()}
function save(){mem=DB;try{localStorage.setItem(K,JSON.stringify(DB))}catch(e){}}
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function applyTheme(theme){document.documentElement.dataset.theme=theme;try{localStorage.setItem('Internhub_theme',theme)}catch(e){}}
function savedTheme(){try{return localStorage.getItem('Internhub_theme')}catch(e){return null}}
function initialTheme(){return savedTheme()||((window.matchMedia&&window.matchMedia('(prefers-color-scheme:dark)').matches)?'dark':'light')}
function init(){DB=load();save();let id=null;try{id=sessionStorage.getItem(SK)}catch(e){}
me=DB.users.find(u=>u.id===id)||null;view=me?(me.role==='admin'?'dash':'jobs'):'auth';render()}
applyTheme(initialTheme());
function login(u){me=u;try{sessionStorage.setItem(SK,u.id)}catch(e){}view=u.role==='admin'?'dash':'jobs';render()}
function logout(){me=null;try{sessionStorage.removeItem(SK)}catch(e){}view='auth';render()}
let authTab='login',selJob='';
function tagFor(s){return s==='Selected'?'ok':s==='Rejected'?'bad':s==='Applied'?'':'warn'}
function render(){const a=document.getElementById('app');
if(!me){a.innerHTML=`<main class="auth-layout"><button class="theme-toggle auth-theme" data-a="theme" aria-label="Switch color theme">${document.documentElement.dataset.theme==='dark'?'☀':'☾'}</button><section class="auth-story"><div class="brand-mark">IH</div><div><span class="story-label">Campus careers, organized</span><h1>Turn ambition into your next opportunity.</h1><p>Discover drives, track applications, and prepare for placement day from one focused workspace.</p></div><div class="story-stats"><div><strong>One place</strong><span>All opportunities</span></div><div><strong>Real-time</strong><span>Application updates</span></div></div></section>${authView()}</main>`;return}
const nav=me.role==='admin'?[['dash','Dashboard'],['ajobs','Jobs'],['apps','Applicants'],['studs','Students']]:[['jobs','Jobs'],['my','My Applications'+badge()],['pred','Prediction'],['prof','Profile']];
a.innerHTML=`<header class="top"><button class="brand" data-a="nav" data-id="${me.role==='admin'?'dash':'jobs'}" aria-label="Go to dashboard"><span class="brand-mark">IH</span><span>InternHub</span></button><nav>${nav.map(n=>`<button data-a="nav" data-id="${n[0]}" class="${view===n[0]?'on':''}">${n[1]}</button>`).join('')}</nav>
<button class="theme-toggle" data-a="theme" aria-label="Switch color theme" title="Switch color theme"><span class="theme-icon">${document.documentElement.dataset.theme==='dark'?'☀':'☾'}</span></button>
<span class="mu user-name">${esc(me.name)}<small>${me.role}</small></span><button class="btn sec logout" data-a="logout">Log out</button></header><main class="wrap">${body()}</main>`}
function authView(){const L=authTab==='login';return`<div class="auth card"><span class="auth-kicker">${L?'Welcome back':'Join the portal'}</span><h2>${L?'Sign in to InternHub':'Create your student account'}</h2><p class="mu auth-subtitle">${L?'Continue to your placement workspace':'Start discovering campus opportunities'}</p>
<div class="tabs"><button class="btn ${L?'':'sec'}" data-a="tab" data-id="login">Login</button><button class="btn ${L?'sec':''}" data-a="tab" data-id="reg">Student sign up</button></div>
<form data-f="${L?'login':'reg'}">
${L?'':`<label>Full name</label><input name="name" required><label>Branch</label><select name="branch">${BR.map(b=>`<option>${b}</option>`).join('')}</select><label>CGPA</label><input name="cgpa" type="number" step="0.01" min="0" max="10" required>`}
<label>Email</label><input name="email" type="email" required><label>Password</label><input name="pw" type="password" minlength="6" required>
<div class="err" id="err"></div><button class="btn" style="width:100%">${L?'Login':'Create account'}</button></form>
${L?'<p class="mu">Demo admin: admin@college.edu / admin123</p>':''}</div>`}
function body(){const v=view;
if(me.role==='admin'){return v==='dash'?dash():v==='ajobs'?ajobs():v==='apps'?applicants():studs()}
return v==='jobs'?sjobs():v==='my'?myapps():v==='pred'?pred():prof()}
function pred(){const{pct,f}=predict(me),col=pct>=65?'var(--ok)':pct>=40?'var(--warn)':'var(--bad)',vd=pct===100?'Placed – you have an offer!':pct>=65?'Likely to be placed':pct>=40?'Moderate chance of placement':'Low chance right now – improve the areas below';
const tips=f.filter(x=>x[1]<x[2]);const el=DB.jobs.filter(j=>!eligible(me,j));
return`<h2>Placement prediction</h2><div class="card pred"><svg width="140" height="140" viewBox="0 0 140 140"><circle cx="70" cy="70" r="52" fill="none" stroke="var(--bd)" stroke-width="12"/><circle cx="70" cy="70" r="52" fill="none" stroke="${col}" stroke-width="12" stroke-linecap="round" stroke-dasharray="${pct*3.267} 327" transform="rotate(-90 70 70)"/><text x="70" y="78" text-anchor="middle" font-size="28" font-weight="700" fill="var(--tx)">${pct}%</text></svg>
<div style="flex:1;min-width:200px"><h3 style="color:${col}">${vd}</h3><p class="mu">Chance of being placed: <b>${pct}%</b> · Not placed: <b>${100-pct}%</b>. This is an estimate from your profile and activity, not a guarantee.</p></div></div>
<div class="card"><h3>Score breakdown</h3>${f.map(x=>`<div style="margin-top:10px"><div class="row sp mu"><span>${x[0]}</span><span>${Math.round(x[1])}/${x[2]}</span></div><div class="bar"><i style="width:${x[1]/x[2]*100}%"></i></div></div>`).join('')}</div>
<div class="card"><h3>How to improve</h3>${tips.length?`<ul>${tips.map(x=>`<li>${x[3]}</li>`).join('')}</ul>`:'<p class="mu">Great profile! Keep applying and preparing for interviews.</p>'}</div>
<div class="card tw"><h3>Chance per drive</h3>${el.length?`<table><tr><th>Company</th><th>Role</th><th>Package</th><th>Your chance</th></tr>${el.map(j=>`<tr><td>${esc(j.company)}</td><td>${esc(j.role)}</td><td>${pk(j)}</td><td><b>${jobChance(me,j)}%</b></td></tr>`).join('')}</table>`:'<p class="mu">No eligible drives right now. Complete your profile or check back later.</p>'}</div>`}

let F={q:'',type:'',mode:'',sort:'chance',elig:false,saved:false,open:'',st:'',br:'',sel:''},SQ='',NEW=new Set();
const JT=['Full-time','Internship','Intern + PPO'],MD=['On-site','Hybrid','Remote'],PF=['phone','gradYear','tenth','twelfth','resume','linkedin','github','skills','prefRole','certs'];
const sk=s=>(s||'').split(/[,\n]/).map(x=>x.trim().toLowerCase()).filter(Boolean);
const days=d=>Math.ceil((new Date(d+'T23:59:59')-new Date())/864e5);
const pk=j=>j.pkg+(j.type==='Internship'?'k/mo':' LPA');
const $=id=>document.getElementById(id);
function match(u,j){const r=sk(j.skills);if(!r.length)return null;const m=sk(u.skills);return Math.round(r.filter(x=>m.includes(x)).length/r.length*100)}
function badge(){if(me.role!=='student')return'';const n=DB.apps.filter(a=>a.sid===me.id&&a.unread).length;return n?`<span class="badge">${n}</span>`:''}
function csv(name,rows){const t=rows.map(r=>r.map(c=>'"'+String(c??'').replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv'}));a.download=name;a.click()}
function seed(){const d=n=>new Date(Date.now()+n*864e5).toISOString().slice(0,10);
return{users:[{id:'admin',role:'admin',name:'Placement Officer',email:'admin@college.edu',pw:h('admin123')}],jobs:[
{id:uid(),company:'TechNova',role:'Software Engineer',type:'Full-time',mode:'Hybrid',pkg:8,loc:'Pune',minCgpa:7,maxBacklogs:0,openings:10,branches:'CSE,IT',skills:'JavaScript, React, SQL',rounds:'Online test > Technical > HR',contact:'hr@technova.com',deadline:d(30),desc:'Full-stack development on product teams.'},
{id:uid(),company:'CoreWorks',role:'Graduate Engineer Trainee',type:'Full-time',mode:'On-site',pkg:5.5,loc:'Mumbai',minCgpa:6,maxBacklogs:2,openings:25,branches:'All',skills:'Communication, AutoCAD',rounds:'Aptitude > Interview',contact:'careers@coreworks.in',deadline:d(20),desc:'Open to all branches.'},
{id:uid(),company:'DataLeaf',role:'Data Analyst Intern',type:'Internship',mode:'Remote',pkg:25,loc:'Remote',minCgpa:6.5,maxBacklogs:1,openings:5,branches:'CSE,IT,ECE',skills:'Python, SQL, Excel',rounds:'Assignment > Interview',contact:'jobs@dataleaf.io',deadline:d(14),desc:'6-month internship with PPO opportunity.'}],apps:[]}}
function eligible(u,j){if(!u.cgpa)return 'Complete your profile (CGPA) first';if(+u.cgpa<+j.minCgpa)return 'Min CGPA '+j.minCgpa;
if(+(u.backlogs||0)>+(j.maxBacklogs??99))return 'Max '+j.maxBacklogs+' backlogs allowed';
const b=j.branches.split(',').map(s=>s.trim().toLowerCase());if(!b.includes('all')&&!b.includes((u.branch||'').toLowerCase()))return 'Branch not eligible';
if(j.deadline&&days(j.deadline)<0)return 'Deadline passed';return ''}
function predict(u){const apps=DB.apps.filter(a=>a.sid===u.id),n=sk(u.skills).length,c=+u.cgpa||0,p=['phone','linkedin','github'].filter(k=>u[k]).length;
const f=[['Academics (CGPA)',Math.max(0,Math.min(1,(c-5)/4))*30,30,'Raise your CGPA toward 8+ to widen eligibility.'],
['Skills',Math.min(n,8)/8*15,15,'List more skills (aim for 8+), separated by commas.'],
['Resume',u.resume?5:0,5,'Add a resume link to your profile.'],
['Profile links',p/3*5,5,'Add phone, LinkedIn and GitHub.'],
['Activity',Math.min(apps.length,5)/5*10,10,'Apply to more eligible drives (aim for 5 or more).'],
['Progress',apps.some(a=>['Shortlisted','Interview','Selected'].includes(a.status))?10:0,10,'Get shortlisted in a drive to boost this score.'],
['Experience',Math.min(+u.internships||0,2)/2*8+Math.min(+u.projects||0,3)/3*7,15,'Add internships (up to 2) and projects (up to 3).'],
['Backlogs',Math.max(0,10-4*(+u.backlogs||0)),10,'Clear active backlogs to improve eligibility.']];
let pct=Math.max(3,Math.min(95,Math.round(f.reduce((t,x)=>t+x[1],0))));if(apps.some(a=>a.status==='Selected'))pct=100;return{pct,f}}
function jobChance(u,j){const p=predict(u).pct,m=match(u,j);return Math.max(3,Math.min(95,Math.round(p+((+u.cgpa||0)-(+j.minCgpa||0))*5-Math.max(0,(+j.pkg||0)-(j.type==='Internship'?99:6))*1.5+(m==null?0:(m-50)/5))))}
function jcard(j){const ap=DB.apps.find(a=>a.jid===j.id&&a.sid===me.id),why=eligible(me,j),d=days(j.deadline),sv=(me.saved||[]).includes(j.id),m=match(me,j),o=F.open===j.id,mine=sk(me.skills);
return`<div class="card"><div class="row sp"><div><h3>${esc(j.company)} – ${esc(j.role)}</h3><span class="mu">${pk(j)} · ${esc(j.loc)} · CGPA ≥ ${j.minCgpa} · ${esc(j.branches)}</span></div>
<div class="row"><button class="btn sec" data-a="save" data-id="${j.id}" title="Save">${sv?'★':'☆'}</button>${ap?`<span class="tag ${tagFor(ap.status)}">${ap.status}</span>`:`<button class="btn" data-a="apply" data-id="${j.id}" ${why?'disabled':''}>Apply</button>`}</div></div>
<div style="margin-top:8px"><span class="tag">${esc(j.type||'Full-time')}</span><span class="tag">${esc(j.mode||'On-site')}</span><span class="tag">${j.openings||'–'} openings</span><span class="tag ${d<0?'bad':d<=5?'warn':''}">${d<0?'Closed':d+' days left'}</span>${why?'':`<span class="tag ok">Your chance: ${jobChance(me,j)}%</span>`}${m==null?'':`<span class="tag ${m>=60?'ok':'warn'}">Skill match ${m}%</span>`}${!ap&&why?`<span class="tag bad">${why}</span>`:''}</div>
${o?`<div class="det"><p>${esc(j.desc)}</p><p class="mu"><b>Rounds:</b> ${esc(j.rounds||'–')}</p><p class="mu"><b>Contact:</b> ${esc(j.contact||'–')} · <b>Max backlogs:</b> ${j.maxBacklogs??'–'}</p><div>${sk(j.skills).map(s=>`<span class="tag ${mine.includes(s)?'ok':'bad'}">${mine.includes(s)?'✓':'✗'} ${esc(s)}</span>`).join('')}</div></div>`:''}
<p style="margin:8px 0 0"><button class="btn sec" data-a="open" data-id="${j.id}">${o?'Hide details':'Details'}</button></p></div>`}
function jlist(){const q=F.q.toLowerCase(),L=DB.jobs.filter(j=>(!q||(j.company+j.role+j.loc+(j.skills||'')).toLowerCase().includes(q))&&(!F.type||j.type===F.type)&&(!F.mode||j.mode===F.mode)&&(!F.elig||!eligible(me,j))&&(!F.saved||(me.saved||[]).includes(j.id)));
const v=j=>F.sort==='pkg'?-j.pkg:F.sort==='deadline'?new Date(j.deadline):-jobChance(me,j);L.sort((a,b)=>v(a)-v(b));return L.map(jcard).join('')||'<div class="empty">No drives match your filters.</div>'}
function sel(a,cur,all,opts){return`<select data-a="${a}"><option value="">${all}</option>${opts.map(o=>`<option ${cur===o?'selected':''}>${o}</option>`).join('')}</select>`}
function sjobs(){return`<h2>Open drives</h2><div class="card fbar"><input data-a="fq" placeholder="Search company, role, location or skill" value="${esc(F.q)}">${sel('ftype',F.type,'All types',JT)}${sel('fmode',F.mode,'Any mode',MD)}
<select data-a="fsort">${[['chance','Best chance'],['pkg','Highest pay'],['deadline','Deadline soon']].map(o=>`<option value="${o[0]}" ${F.sort===o[0]?'selected':''}>${o[1]}</option>`).join('')}</select>
<label class="chk"><input type="checkbox" data-a="felig" ${F.elig?'checked':''}>Eligible only</label><label class="chk"><input type="checkbox" data-a="fsaved" ${F.saved?'checked':''}>Saved</label></div><div id="jl">${jlist()}</div>`}
function myapps(){const ap=DB.apps.filter(a=>a.sid===me.id);
return`<h2>My applications</h2>${ap.map(a=>{const j=DB.jobs.find(x=>x.id===a.jid);if(!j)return'';const i=ST.indexOf(a.status);
return`<div class="card"><div class="row sp"><div><h3>${esc(j.company)} – ${esc(j.role)} ${NEW.has(a.id)?'<span class="tag warn">Updated</span>':''}</h3><span class="mu">Applied ${a.date} · ${pk(j)}</span></div>${a.status==='Applied'?`<button class="btn del" data-a="withdraw" data-id="${a.id}">Withdraw</button>`:''}</div>
<div style="margin-top:8px">${ST.slice(0,4).map((s,k)=>`<span class="tag ${a.status==='Rejected'?'':k<=i?'ok':''}" style="opacity:${k<=i&&a.status!=='Rejected'?1:.45}">${s}</span>`).join('')}${a.status==='Rejected'?'<span class="tag bad">Rejected</span>':''}</div>
${a.iv?`<p class="mu">📅 Interview or test date: <b>${a.iv}</b></p>`:''}${a.rm?`<p class="mu">💬 Recruiter note: ${esc(a.rm)}</p>`:''}</div>`}).join('')||'<div class="empty">You have not applied to any drive yet.</div>'}`}
function fld(l,n,t,v,x=''){return`<div><label>${l}</label><input name="${n}" type="${t}" value="${esc(v)}" ${x}></div>`}
function prof(){const done=Math.round(PF.filter(k=>me[k]).length/PF.length*100);
return`<h2>My profile</h2><div class="card"><div class="row sp mu"><span>Profile completeness</span><b>${done}%</b></div><div class="bar"><i style="width:${done}%"></i></div></div><div class="card"><form data-f="prof"><div class="grid">
${fld('Full name','name','text',me.name,'required')}<div><label>Email</label><input value="${esc(me.email)}" disabled></div>
<div><label>Branch</label><select name="branch">${BR.map(b=>`<option ${b===me.branch?'selected':''}>${b}</option>`).join('')}</select></div>
${fld('Graduation year','gradYear','number',me.gradYear,'min="2024" max="2032"')}${fld('CGPA','cgpa','number',me.cgpa,'step="0.01" min="0" max="10" required')}
${fld('10th percentage','tenth','number',me.tenth,'min="0" max="100" step="0.1"')}${fld('12th or diploma percentage','twelfth','number',me.twelfth,'min="0" max="100" step="0.1"')}
${fld('Active backlogs','backlogs','number',me.backlogs||0,'min="0"')}${fld('Internships done','internships','number',me.internships||0,'min="0"')}${fld('Projects built','projects','number',me.projects||0,'min="0"')}
${fld('Phone','phone','tel',me.phone)}${fld('Preferred role','prefRole','text',me.prefRole,'placeholder="e.g. Backend developer"')}
${fld('Resume link','resume','url',me.resume,'placeholder="https://..."')}${fld('LinkedIn URL','linkedin','url',me.linkedin)}${fld('GitHub URL','github','url',me.github)}</div>
<label>Skills (comma separated)</label><textarea name="skills">${esc(me.skills)}</textarea><label>Certifications and achievements</label><textarea name="certs">${esc(me.certs)}</textarea><p></p><button class="btn">Save profile</button></form></div>`}
function dash(){const st=DB.users.filter(u=>u.role==='student'),pl=new Set(DB.apps.filter(a=>a.status==='Selected').map(a=>a.sid)),n=Math.max(1,DB.apps.length);
const bars=ST.map(s=>{const c=DB.apps.filter(a=>a.status===s).length;return`<div style="margin-top:10px"><div class="row sp mu"><span>${s}</span><span>${c}</span></div><div class="bar"><i style="width:${c/n*100}%"></i></div></div>`}).join('');
const br=BR.map(b=>[b,st.filter(u=>u.branch===b)]).filter(x=>x[1].length),top=DB.jobs.map(j=>[j,DB.apps.filter(a=>a.jid===j.id).length]).sort((a,b)=>b[1]-a[1]).slice(0,5);
return`<h2>Dashboard</h2><div class="grid"><div class="card"><div class="stat">${st.length}</div>Students</div><div class="card"><div class="stat">${DB.jobs.length}</div>Open drives</div><div class="card"><div class="stat">${DB.apps.length}</div>Applications</div><div class="card"><div class="stat">${pl.size}</div>Students placed</div></div>
<div class="grid"><div class="card"><h3>Placement rate</h3><div class="stat">${st.length?Math.round(pl.size/st.length*100):0}%</div><p class="mu">of registered students have an offer.</p></div><div class="card"><h3>Application pipeline</h3>${bars}</div></div>
<div class="grid"><div class="card tw"><h3>Branch-wise placement</h3>${br.length?`<table><tr><th>Branch</th><th>Students</th><th>Placed</th></tr>${br.map(x=>`<tr><td>${x[0]}</td><td>${x[1].length}</td><td>${x[1].filter(u=>pl.has(u.id)).length}</td></tr>`).join('')}</table>`:'<p class="mu">No data yet.</p>'}</div>
<div class="card tw"><h3>Most applied drives</h3>${top.length?`<table><tr><th>Drive</th><th>Applicants</th></tr>${top.map(x=>`<tr><td>${esc(x[0].company)} – ${esc(x[0].role)}</td><td>${x[1]}</td></tr>`).join('')}</table>`:'<p class="mu">No drives.</p>'}</div></div>`}
function ajobs(){const o=(a,l)=>`<select name="${a}">${l.map(x=>`<option>${x}</option>`).join('')}</select>`;
return`<h2>Manage jobs</h2><div class="card"><h3>Post a new drive</h3><form data-f="job"><div class="grid">
${fld('Company','company','text','','required')}${fld('Role','role','text','','required')}<div><label>Type</label>${o('type',JT)}</div><div><label>Work mode</label>${o('mode',MD)}</div>
${fld('Package (LPA) or stipend (k per month)','pkg','number','','step="0.1" required')}${fld('Location','loc','text','','required')}${fld('Min CGPA','minCgpa','number','6','step="0.1" required')}${fld('Max backlogs allowed','maxBacklogs','number','0','min="0" required')}
${fld('Openings','openings','number','1','min="1"')}${fld('Branches (comma separated or All)','branches','text','All','required')}${fld('Deadline','deadline','date','','required')}${fld('Required skills (comma separated)','skills','text','')}
${fld('Selection rounds','rounds','text','','placeholder="Test > Technical > HR"')}${fld('Contact email','contact','email','')}</div><label>Description</label><textarea name="desc"></textarea><p></p><button class="btn">Post job</button></form></div>
${DB.jobs.map(j=>`<div class="card row sp"><div><h3>${esc(j.company)} – ${esc(j.role)}</h3><span class="mu">${esc(j.type||'Full-time')} · ${esc(j.mode||'On-site')} · ${pk(j)} · ${esc(j.loc)} · CGPA ≥ ${j.minCgpa} · ${j.openings||'–'} openings · by ${j.deadline} · ${DB.apps.filter(a=>a.jid===j.id).length} applicants</span></div><button class="btn del" data-a="deljob" data-id="${j.id}">Delete</button></div>`).join('')||'<div class="empty">No jobs yet.</div>'}`}
function appRows(){return DB.apps.filter(a=>a.jid===selJob&&(!F.st||a.status===F.st))}
function applicants(){if(!selJob||!DB.jobs.find(j=>j.id===selJob))selJob=DB.jobs[0]?.id||'';const j=DB.jobs.find(x=>x.id===selJob)||{},ap=appRows();
return`<h2>Applicants</h2><div class="card fbar"><select data-a="seljob">${DB.jobs.map(x=>`<option value="${x.id}" ${x.id===selJob?'selected':''}>${esc(x.company)} – ${esc(x.role)}</option>`).join('')}</select>${sel('fstat',F.st,'All statuses',ST)}<button class="btn sec" data-a="expapps">Export CSV</button></div>
<div class="card tw">${ap.length?`<table><tr><th>Name</th><th>Branch</th><th>CGPA</th><th>Backlogs</th><th>Skill match</th><th>Chance</th><th>Resume</th><th>Status</th><th>Interview date</th><th>Remark</th></tr>${ap.map(a=>{const u=DB.users.find(x=>x.id===a.sid)||{},m=match(u,j);return`<tr><td>${esc(u.name)}<div class="mu">${esc(u.email)}</div></td><td>${esc(u.branch)}</td><td>${esc(u.cgpa)}</td><td>${u.backlogs||0}</td><td>${m==null?'–':m+'%'}</td><td><b>${jobChance(u,j)}%</b></td><td>${u.resume?`<a href="${esc(u.resume)}" target="_blank" rel="noopener">View</a>`:'–'}</td>
<td><select data-a="status" data-id="${a.id}">${ST.map(s=>`<option ${s===a.status?'selected':''}>${s}</option>`).join('')}</select></td><td><input type="date" data-a="iv" data-id="${a.id}" value="${esc(a.iv)}"></td><td><input data-a="remark" data-id="${a.id}" value="${esc(a.rm)}" placeholder="Note to student"></td></tr>`}).join('')}</table>`:'<div class="empty">No applicants match.</div>'}</div>`}
function studTable(){const q=SQ.toLowerCase(),L=DB.users.filter(u=>u.role==='student'&&(!F.br||u.branch===F.br)&&(!q||(u.name+u.email+(u.skills||'')).toLowerCase().includes(q)));
return L.length?`<table><tr><th>Name</th><th>Branch</th><th>CGPA</th><th>Backlogs</th><th>Skills</th><th>Applied</th><th>Chance</th><th></th></tr>${L.map(u=>`<tr><td>${esc(u.name)}<div class="mu">${esc(u.email)}</div></td><td>${esc(u.branch)}</td><td>${esc(u.cgpa)}</td><td>${u.backlogs||0}</td><td>${esc(u.skills||'–')}</td><td>${DB.apps.filter(a=>a.sid===u.id).length}</td><td><b>${predict(u).pct}%</b></td><td><button class="btn sec" data-a="sview" data-id="${u.id}">View</button> <button class="btn del" data-a="delstud" data-id="${u.id}">Remove</button></td></tr>`).join('')}</table>`:'<div class="empty">No students found.</div>'}
function sdet(u){const r=[['Graduation year','gradYear'],['10th %','tenth'],['12th or diploma %','twelfth'],['Internships','internships'],['Projects','projects'],['Phone','phone'],['Preferred role','prefRole'],['LinkedIn','linkedin'],['GitHub','github'],['Certifications','certs']];
return`<div class="card"><h3>${esc(u.name)} – full profile</h3><div class="grid">${r.map(x=>`<div><span class="mu">${x[0]}</span><div>${esc(u[x[1]]||'–')}</div></div>`).join('')}</div></div>`}
function studs(){const u=DB.users.find(x=>x.id===F.sel);return`<h2>Students</h2><div class="card fbar"><input data-a="sq" placeholder="Search name, email or skill" value="${esc(SQ)}">${sel('sbr',F.br,'All branches',BR)}<button class="btn sec" data-a="exps">Export CSV</button></div>${u?sdet(u):''}<div class="card tw" id="tl">${studTable()}</div>`}
function act(a,id){
if(a==='nav'&&id==='my'){NEW=new Set(DB.apps.filter(x=>x.sid===me.id&&x.unread).map(x=>x.id));DB.apps.forEach(x=>{if(x.sid===me.id)x.unread=false});save();view='my';render();return true}
if(a==='nav'){F.sel='';return false}
if(a==='save'){const s=me.saved=me.saved||[],i=s.indexOf(id);i<0?s.push(id):s.splice(i,1);save();$('jl').innerHTML=jlist();return true}
if(a==='open'){F.open=F.open===id?'':id;$('jl').innerHTML=jlist();return true}
if(a==='sview'){F.sel=F.sel===id?'':id;render();return true}
if(a==='expapps'){const j=DB.jobs.find(x=>x.id===selJob)||{};csv('applicants.csv',[['Name','Email','Branch','CGPA','Backlogs','Status','Interview date','Remark']].concat(appRows().map(a=>{const u=DB.users.find(x=>x.id===a.sid)||{};return[u.name,u.email,u.branch,u.cgpa,u.backlogs||0,a.status,a.iv,a.rm]})));return true}
if(a==='exps'){csv('students.csv',[['Name','Email','Branch','CGPA','Backlogs','Year','Phone','Skills','Chance %']].concat(DB.users.filter(u=>u.role==='student').map(u=>[u.name,u.email,u.branch,u.cgpa,u.backlogs||0,u.gradYear,u.phone,u.skills,predict(u).pct])));return true}
return false}
document.addEventListener('input',e=>{const t=e.target;if(t.dataset.a==='fq'){F.q=t.value;$('jl').innerHTML=jlist()}else if(t.dataset.a==='sq'){SQ=t.value;$('tl').innerHTML=studTable()}});
document.addEventListener('change',e=>{const t=e.target,a=t.dataset.a;if(!a)return;const up=()=>{$('jl').innerHTML=jlist()};
if(a==='ftype'){F.type=t.value;up()}else if(a==='fmode'){F.mode=t.value;up()}else if(a==='fsort'){F.sort=t.value;up()}else if(a==='felig'){F.elig=t.checked;up()}else if(a==='fsaved'){F.saved=t.checked;up()}
else if(a==='fstat'){F.st=t.value;render()}else if(a==='sbr'){F.br=t.value;$('tl').innerHTML=studTable()}
else if(a==='iv'||a==='remark'){const x=DB.apps.find(z=>z.id===t.dataset.id);x[a==='iv'?'iv':'rm']=t.value;x.unread=true;save();toast('Saved')}});
document.addEventListener('submit',async e=>{const f=e.target.dataset.f;if(!f)return;e.preventDefault();
const d=Object.fromEntries(new FormData(e.target)),err=document.getElementById('err');
if(f==='login'){const u=DB.users.find(x=>x.email===d.email.trim().toLowerCase()&&x.pw===h(d.pw));if(!u){err.textContent='Invalid email or password';return}login(u)}
else if(f==='reg'){const em=d.email.trim().toLowerCase();if(DB.users.some(x=>x.email===em)){err.textContent='Email already registered';return}
const u={id:uid(),role:'student',name:d.name.trim(),email:em,pw:h(d.pw),branch:d.branch,cgpa:d.cgpa,skills:'',phone:'',resume:''};DB.users.push(u);save();login(u);toast('Welcome!')}
else if(f==='job'){DB.jobs.push({id:uid(),...d});save();toast('Job posted');render()}
else if(f==='prof'){Object.assign(me,d);save();toast('Profile saved');render()}});
document.addEventListener('click',e=>{const b=e.target.closest('[data-a]');if(!b||b.tagName==='SELECT')return;const a=b.dataset.a,id=b.dataset.id;
if(act(a,id,b)){}else if(a==='nav'){view=id;render()}else if(a==='logout')logout();else if(a==='tab'){authTab=id;render()}
else if(a==='theme'){const next=document.documentElement.dataset.theme==='dark'?'light':'dark';applyTheme(next);render()}
else if(a==='apply'){DB.apps.push({id:uid(),jid:id,sid:me.id,status:'Applied',date:new Date().toISOString().slice(0,10)});save();toast('Application submitted');render()}
else if(a==='withdraw'){DB.apps=DB.apps.filter(x=>x.id!==id);save();render()}
else if(a==='deljob'&&confirm('Delete this job and its applications?')){DB.jobs=DB.jobs.filter(j=>j.id!==id);DB.apps=DB.apps.filter(x=>x.jid!==id);save();render()}
else if(a==='delstud'&&confirm('Remove this student?')){DB.users=DB.users.filter(u=>u.id!==id);DB.apps=DB.apps.filter(x=>x.sid!==id);save();render()}});
document.addEventListener('change',e=>{const s=e.target;if(s.dataset.a==='seljob'){selJob=s.value;render()}
else if(s.dataset.a==='status'){const a=DB.apps.find(x=>x.id===s.dataset.id);a.status=s.value;a.unread=true;save();toast('Status updated')}});
init();
