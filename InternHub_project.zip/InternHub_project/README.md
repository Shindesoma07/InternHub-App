# InternHub – Campus Placement Portal (v2)

Open `placement-portal/index.html` in a browser. No install or build step.
Admin login: admin@college.edu / admin123 (students sign up on the login screen).
Data is stored in the browser (localStorage), so it is per device.

Files: index.html (page), style.css (styling + dark mode), app.js (all logic).
